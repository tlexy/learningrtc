./configure --enable-shared --extra-ldflags=-Wl,--output-def=libx264.def
LIB /DEF:libx264.def

#lib /machine:x64 /def:libfftw3f-3.def